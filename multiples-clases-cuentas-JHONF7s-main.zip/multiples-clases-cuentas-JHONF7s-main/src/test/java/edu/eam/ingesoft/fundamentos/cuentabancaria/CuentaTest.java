package edu.eam.ingesoft.fundamentos.cuentabancaria;

import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cuenta;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests unitarios para la clase Cuenta.
 * Valida solo lo enseñado en las LECCIONES 1 y 2 del sitio web didáctico.
 */
class CuentaTest {

    private static final double DELTA = 0.01;

    // ================================================================
    // LECCIÓN 1: CONSTRUCTOR
    // ================================================================

    @Test
    @DisplayName("Lección 1: Constructor de cuenta de AHORROS inicializa correctamente")
    void testConstructorAhorros() {
        // Crear cuenta de ahorros
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_AHORROS, "001");

        // Verificar que los atributos se inicializaron correctamente
        assertEquals("001", cuenta.getNumeroCuenta(), "El número de cuenta debe ser '001'");
        assertEquals(Cuenta.TIPO_AHORROS, cuenta.getTipo(), "El tipo debe ser AHORROS");
        assertEquals(0.0, cuenta.getSaldo(), DELTA, "El saldo inicial debe ser 0.0");
        assertEquals(0, cuenta.getTransaccionesMes(), "Las transacciones iniciales deben ser 0");
    }

    @Test
    @DisplayName("Lección 1: Constructor de cuenta CORRIENTE inicializa correctamente")
    void testConstructorCorriente() {
        // Crear cuenta corriente
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_CORRIENTE, "002");

        // Verificar que los atributos se inicializaron correctamente
        assertEquals("002", cuenta.getNumeroCuenta(), "El número de cuenta debe ser '002'");
        assertEquals(Cuenta.TIPO_CORRIENTE, cuenta.getTipo(), "El tipo debe ser CORRIENTE");
        assertEquals(0.0, cuenta.getSaldo(), DELTA, "El saldo inicial debe ser 0.0");
        assertEquals(0, cuenta.getTransaccionesMes(), "Las transacciones iniciales deben ser 0");
    }

    @Test
    @DisplayName("Lección 1: Constructor con diferentes números de cuenta")
    void testConstructorDiferentesNumeros() {
        Cuenta c1 = new Cuenta(Cuenta.TIPO_AHORROS, "123");
        Cuenta c2 = new Cuenta(Cuenta.TIPO_CORRIENTE, "ABC-456");

        assertEquals("123", c1.getNumeroCuenta());
        assertEquals("ABC-456", c2.getNumeroCuenta());
    }

    // ================================================================
    // LECCIÓN 2: ENCAPSULAMIENTO - Getters y Setters
    // ================================================================

    @Test
    @DisplayName("Lección 2: Getter de numeroCuenta funciona correctamente")
    void testGetterNumeroCuenta() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_AHORROS, "001");

        String numero = cuenta.getNumeroCuenta();

        assertEquals("001", numero, "getNumeroCuenta() debe retornar el número correcto");
    }

    @Test
    @DisplayName("Lección 2: Getter de tipo funciona correctamente")
    void testGetterTipo() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_CORRIENTE, "002");

        String tipo = cuenta.getTipo();

        assertEquals(Cuenta.TIPO_CORRIENTE, tipo, "getTipo() debe retornar el tipo correcto");
    }

    @Test
    @DisplayName("Lección 2: Getter de saldo funciona correctamente")
    void testGetterSaldo() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_AHORROS, "001");

        double saldo = cuenta.getSaldo();

        assertEquals(0.0, saldo, DELTA, "getSaldo() debe retornar 0.0 para cuenta nueva");
    }

    @Test
    @DisplayName("Lección 2: Getter de transaccionesMes funciona correctamente")
    void testGetterTransaccionesMes() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_AHORROS, "001");

        int transacciones = cuenta.getTransaccionesMes();

        assertEquals(0, transacciones, "getTransaccionesMes() debe retornar 0 para cuenta nueva");
    }

    @Test
    @DisplayName("Lección 2: Setter de tipo permite cambiar de AHORROS a CORRIENTE")
    void testSetterTipo() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_AHORROS, "001");

        // Verificar tipo inicial
        assertEquals(Cuenta.TIPO_AHORROS, cuenta.getTipo());

        // Cambiar tipo usando setter
        cuenta.setTipo(Cuenta.TIPO_CORRIENTE);

        // Verificar que cambió
        assertEquals(Cuenta.TIPO_CORRIENTE, cuenta.getTipo(),
                     "setTipo() debe cambiar el tipo de la cuenta");
    }

    @Test
    @DisplayName("Lección 2: Todos los getters funcionan después del constructor")
    void testTodosLosGetters() {
        Cuenta cuenta = new Cuenta(Cuenta.TIPO_CORRIENTE, "XYZ-789");

        // Verificar que todos los getters funcionan
        assertNotNull(cuenta.getNumeroCuenta(), "getNumeroCuenta() no debe retornar null");
        assertNotNull(cuenta.getTipo(), "getTipo() no debe retornar null");
        assertTrue(cuenta.getSaldo() >= 0, "getSaldo() debe retornar un valor válido");
        assertTrue(cuenta.getTransaccionesMes() >= 0, "getTransaccionesMes() debe retornar un valor válido");
    }
}
