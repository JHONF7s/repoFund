package edu.eam.ingesoft.fundamentos.cuentabancaria;

import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cliente;
import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cuenta;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests unitarios para la clase Cliente.
 * Valida solo lo enseñado en las LECCIONES 3 y 4 del sitio web didáctico.
 */
class ClienteTest {

    private Cliente cliente;

    @BeforeEach
    void setUp() {
        cliente = new Cliente("Juan Pérez", "1234567890");
    }

    // ================================================================
    // LECCIÓN 3: ARRAYLIST - Crear e inicializar
    // ================================================================

    @Test
    @DisplayName("Lección 3: Constructor inicializa el ArrayList correctamente")
    void testConstructorInicializaArrayList() {
        // Verificar que el constructor del cliente funciona
        assertEquals("Juan Pérez", cliente.getNombre());
        assertEquals("1234567890", cliente.getCedula());

        // IMPORTANTE: Verificar que el ArrayList NO es null
        ArrayList<Cuenta> cuentas = cliente.getCuentas();
        assertNotNull(cuentas, "El ArrayList de cuentas NO debe ser null después del constructor");
    }

    @Test
    @DisplayName("Lección 3: ArrayList inicia vacío (size = 0)")
    void testArrayListIniciaVacio() {
        ArrayList<Cuenta> cuentas = cliente.getCuentas();

        // Verificar que está vacío usando size()
        assertEquals(0, cuentas.size(), "El ArrayList debe iniciar vacío (size = 0)");
    }

    @Test
    @DisplayName("Lección 3: getCuentas() retorna el ArrayList correctamente")
    void testGetCuentasFunciona() {
        ArrayList<Cuenta> cuentas = cliente.getCuentas();

        // Verificar que getCuentas() retorna un ArrayList válido
        assertNotNull(cuentas, "getCuentas() no debe retornar null");
        assertTrue(cuentas instanceof ArrayList, "getCuentas() debe retornar un ArrayList");
    }

    // ================================================================
    // LECCIÓN 4: ARRAYLIST - Agregar elementos con add()
    // ================================================================

    @Test
    @DisplayName("Lección 4: abrirCuenta() agrega la primera cuenta correctamente")
    void testAbrirPrimeraCuenta() {
        // Verificar que inicia vacío
        assertEquals(0, cliente.getCuentas().size());

        // Abrir primera cuenta
        boolean resultado = cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS);

        // Verificar que se abrió exitosamente
        assertTrue(resultado, "abrirCuenta() debe retornar true al abrir la primera cuenta");

        // Verificar que el ArrayList ahora tiene 1 elemento
        assertEquals(1, cliente.getCuentas().size(), "Después de agregar 1 cuenta, size() debe ser 1");
    }

    @Test
    @DisplayName("Lección 4: abrirCuenta() con múltiples cuentas incrementa size()")
    void testAbrirMultiplesCuentas() {
        // Abrir 3 cuentas
        cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("002", Cuenta.TIPO_CORRIENTE);
        cliente.abrirCuenta("003", Cuenta.TIPO_AHORROS);

        // Verificar que size() refleja la cantidad correcta
        assertEquals(3, cliente.getCuentas().size(), "Después de agregar 3 cuentas, size() debe ser 3");
    }

    @Test
    @DisplayName("Lección 4: Puede abrir hasta 6 cuentas (límite máximo)")
    void testAbrirHastaSeisCuentas() {
        // Abrir 6 cuentas (el máximo permitido)
        assertTrue(cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS));
        assertTrue(cliente.abrirCuenta("002", Cuenta.TIPO_CORRIENTE));
        assertTrue(cliente.abrirCuenta("003", Cuenta.TIPO_AHORROS));
        assertTrue(cliente.abrirCuenta("004", Cuenta.TIPO_CORRIENTE));
        assertTrue(cliente.abrirCuenta("005", Cuenta.TIPO_AHORROS));
        assertTrue(cliente.abrirCuenta("006", Cuenta.TIPO_CORRIENTE));

        // Verificar que llegó al límite
        assertEquals(6, cliente.getCuentas().size(), "Debe permitir abrir 6 cuentas");
    }

    @Test
    @DisplayName("Lección 4: Rechaza la 7ma cuenta (valida límite con size())")
    void testRechazarSeptimaCuenta() {
        // Abrir 6 cuentas (el máximo)
        cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("002", Cuenta.TIPO_CORRIENTE);
        cliente.abrirCuenta("003", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("004", Cuenta.TIPO_CORRIENTE);
        cliente.abrirCuenta("005", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("006", Cuenta.TIPO_CORRIENTE);

        // Intentar abrir la 7ma cuenta
        boolean resultado = cliente.abrirCuenta("007", Cuenta.TIPO_AHORROS);

        // Verificar que fue rechazada
        assertFalse(resultado, "abrirCuenta() debe retornar false cuando ya hay 6 cuentas");

        // Verificar que el size() no cambió
        assertEquals(6, cliente.getCuentas().size(), "No debe agregar la 7ma cuenta, size() debe seguir siendo 6");
    }

    @Test
    @DisplayName("Lección 4: Las cuentas agregadas están en el ArrayList")
    void testCuentasEnArrayList() {
        // Abrir 2 cuentas
        cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("002", Cuenta.TIPO_CORRIENTE);

        ArrayList<Cuenta> cuentas = cliente.getCuentas();

        // Verificar que las cuentas están en la lista
        assertEquals(2, cuentas.size());

        // Verificar que la primera cuenta tiene los datos correctos
        Cuenta primera = cuentas.get(0);
        assertEquals("001", primera.getNumeroCuenta());
        assertEquals(Cuenta.TIPO_AHORROS, primera.getTipo());

        // Verificar que la segunda cuenta tiene los datos correctos
        Cuenta segunda = cuentas.get(1);
        assertEquals("002", segunda.getNumeroCuenta());
        assertEquals(Cuenta.TIPO_CORRIENTE, segunda.getTipo());
    }

    @Test
    @DisplayName("Lección 4: Validación funciona correctamente con diferentes números de cuentas")
    void testValidacionConDiferentesNumeros() {
        // Con 0 cuentas: debe permitir
        assertTrue(cliente.abrirCuenta("001", Cuenta.TIPO_AHORROS));
        assertEquals(1, cliente.getCuentas().size());

        // Con 1 cuenta: debe permitir
        assertTrue(cliente.abrirCuenta("002", Cuenta.TIPO_AHORROS));
        assertEquals(2, cliente.getCuentas().size());

        // Con 5 cuentas: debe permitir la 6ta
        cliente.abrirCuenta("003", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("004", Cuenta.TIPO_AHORROS);
        cliente.abrirCuenta("005", Cuenta.TIPO_AHORROS);
        assertTrue(cliente.abrirCuenta("006", Cuenta.TIPO_AHORROS));
        assertEquals(6, cliente.getCuentas().size());

        // Con 6 cuentas: debe rechazar la 7ma
        assertFalse(cliente.abrirCuenta("007", Cuenta.TIPO_AHORROS));
        assertEquals(6, cliente.getCuentas().size());
    }
}
