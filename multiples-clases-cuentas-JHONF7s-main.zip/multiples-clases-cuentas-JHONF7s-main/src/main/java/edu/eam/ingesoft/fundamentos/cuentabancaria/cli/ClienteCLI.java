package edu.eam.ingesoft.fundamentos.cuentabancaria.cli;

import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cliente;
import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cuenta;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Interfaz de línea de comandos (CLI) simplificada.
 * Solo incluye las operaciones enseñadas en las 4 lecciones del sitio web didáctico.
 */
public class ClienteCLI {

    private static final Scanner scanner = new Scanner(System.in);
    private static Cliente clienteActual = null;

    // Colores ANSI para terminal
    private static final String RESET = "\u001B[0m";
    private static final String BOLD = "\u001B[1m";
    private static final String BLUE = "\u001B[34m";
    private static final String GREEN = "\u001B[32m";
    private static final String RED = "\u001B[31m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";

    public static void main(String[] args) {
        mostrarBienvenida();

        boolean continuar = true;
        while (continuar) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    crearCliente();
                    break;
                case 2:
                    abrirCuenta();
                    break;
                case 3:
                    verInformacionCliente();
                    break;
                case 0:
                    continuar = false;
                    mostrarDespedida();
                    break;
                default:
                    mostrarError("Opción inválida. Intente de nuevo.");
            }

            if (continuar && opcion != 0) {
                pausar();
            }
        }

        scanner.close();
    }

    private static void mostrarBienvenida() {
        limpiarPantalla();
        System.out.println(BLUE + BOLD + "╔════════════════════════════════════════════════════════════════╗" + RESET);
        System.out.println(BLUE + BOLD + "║                                                                ║" + RESET);
        System.out.println(BLUE + BOLD + "║         🏦  SISTEMA DE GESTIÓN DE CUENTAS BANCARIAS  🏦        ║" + RESET);
        System.out.println(BLUE + BOLD + "║                                                                ║" + RESET);
        System.out.println(BLUE + BOLD + "║              Ejercicio de Fundamentos de POO                   ║" + RESET);
        System.out.println(BLUE + BOLD + "║                                                                ║" + RESET);
        System.out.println(BLUE + BOLD + "╚════════════════════════════════════════════════════════════════╝" + RESET);
        System.out.println();
        System.out.println(CYAN + "Bienvenido al sistema de gestión de cuentas bancarias." + RESET);
        System.out.println(CYAN + "Por favor, comience creando un cliente." + RESET);
        System.out.println();
        pausar();
    }

    private static void mostrarMenuPrincipal() {
        limpiarPantalla();
        System.out.println(BLUE + BOLD + "═══════════════════════ MENÚ PRINCIPAL ═══════════════════════" + RESET);
        System.out.println();

        if (clienteActual != null) {
            System.out.println(GREEN + "👤 Cliente activo: " + BOLD + clienteActual.getNombre() + RESET);
            System.out.println(GREEN + "📋 Cédula: " + clienteActual.getCedula() + RESET);

            int numCuentas = 0;
            if (clienteActual.getCuentas() != null) {
                numCuentas = clienteActual.getCuentas().size();
            }
            System.out.println(GREEN + "🏦 Cuentas: " + numCuentas + "/6" + RESET);
        } else {
            System.out.println(YELLOW + "⚠ No hay cliente activo" + RESET);
        }

        System.out.println();
        System.out.println(CYAN + "OPCIONES DISPONIBLES:" + RESET);
        System.out.println("  1. 👤 Crear nuevo cliente");
        System.out.println("  2. ➕ Abrir cuenta");
        System.out.println("  3. 📄 Ver información del cliente");
        System.out.println();
        System.out.println("  0. 🚪 Salir");
        System.out.println();
        System.out.println(BLUE + "════════════════════════════════════════════════════════════════" + RESET);
        System.out.print(CYAN + "Seleccione una opción: " + RESET);
    }

    // ================================================================
    // OPCIÓN 1: CREAR CLIENTE
    // ================================================================
    private static void crearCliente() {
        limpiarPantalla();
        System.out.println(BLUE + BOLD + "═══════════════════ CREAR NUEVO CLIENTE ═══════════════════" + RESET);
        System.out.println();

        System.out.print("Ingrese el nombre completo: ");
        String nombre = scanner.nextLine().trim();

        if (nombre.isEmpty()) {
            mostrarError("El nombre no puede estar vacío.");
            return;
        }

        System.out.print("Ingrese la cédula: ");
        String cedula = scanner.nextLine().trim();

        if (cedula.isEmpty()) {
            mostrarError("La cédula no puede estar vacía.");
            return;
        }

        try {
            clienteActual = new Cliente(nombre, cedula);

            System.out.println();
            System.out.println(GREEN + BOLD + "✓ Cliente creado exitosamente!" + RESET);
            System.out.println();
            System.out.println("Nombre: " + nombre);
            System.out.println("Cédula: " + cedula);
        } catch (Exception e) {
            mostrarError("Error al crear el cliente: " + e.getMessage());
        }
    }

    // ================================================================
    // OPCIÓN 2: ABRIR CUENTA
    // ================================================================
    private static void abrirCuenta() {
        limpiarPantalla();
        System.out.println(BLUE + BOLD + "════════════════════ ABRIR NUEVA CUENTA ════════════════════" + RESET);
        System.out.println();

        if (!validarClienteActivo()) {
            return;
        }

        // Mostrar información actual
        int numCuentas = clienteActual.getCuentas() != null ? clienteActual.getCuentas().size() : 0;
        System.out.println(CYAN + "Cuentas actuales: " + numCuentas + "/6" + RESET);

        if (numCuentas >= 6) {
            mostrarError("El cliente ya tiene el máximo de 6 cuentas.");
            return;
        }

        System.out.println();

        // Solicitar número de cuenta
        System.out.print("Ingrese el número de cuenta: ");
        String numeroCuenta = scanner.nextLine().trim();

        if (numeroCuenta.isEmpty()) {
            mostrarError("El número de cuenta no puede estar vacío.");
            return;
        }

        // Solicitar tipo de cuenta
        System.out.println();
        System.out.println("Tipo de cuenta:");
        System.out.println("  1. " + Cuenta.TIPO_AHORROS);
        System.out.println("  2. " + Cuenta.TIPO_CORRIENTE);
        System.out.print("Seleccione (1-2): ");

        int tipoOpcion = leerOpcion();
        String tipo;

        if (tipoOpcion == 1) {
            tipo = Cuenta.TIPO_AHORROS;
        } else if (tipoOpcion == 2) {
            tipo = Cuenta.TIPO_CORRIENTE;
        } else {
            mostrarError("Opción de tipo inválida.");
            return;
        }

        // Intentar abrir la cuenta
        try {
            boolean exito = clienteActual.abrirCuenta(numeroCuenta, tipo);

            System.out.println();
            if (exito) {
                System.out.println(GREEN + BOLD + "✓ Cuenta abierta exitosamente!" + RESET);
                System.out.println();
                System.out.println("Número: " + numeroCuenta);
                System.out.println("Tipo: " + tipo);

                int nuevasCuentas = clienteActual.getCuentas().size();
                System.out.println("Total de cuentas: " + nuevasCuentas + "/6");
            } else {
                mostrarError("No se pudo abrir la cuenta. Límite de cuentas alcanzado (máximo 6).");
            }
        } catch (Exception e) {
            mostrarError("Error al abrir la cuenta: " + e.getMessage());
        }
    }

    // ================================================================
    // OPCIÓN 3: VER INFORMACIÓN DEL CLIENTE
    // ================================================================
    private static void verInformacionCliente() {
        limpiarPantalla();
        System.out.println(BLUE + BOLD + "════════════════ INFORMACIÓN DEL CLIENTE ════════════════" + RESET);
        System.out.println();

        if (!validarClienteActivo()) {
            return;
        }

        System.out.println(CYAN + "Nombre: " + RESET + clienteActual.getNombre());
        System.out.println(CYAN + "Cédula: " + RESET + clienteActual.getCedula());
        System.out.println();

        ArrayList<Cuenta> cuentas = clienteActual.getCuentas();

        if (cuentas == null || cuentas.size() == 0) {
            System.out.println(YELLOW + "⚠ El cliente no tiene cuentas registradas." + RESET);
            return;
        }

        System.out.println(CYAN + "Total de cuentas: " + cuentas.size() + "/6" + RESET);
        System.out.println();
        System.out.println(BLUE + "─────────────────────────────────────────────────────────" + RESET);
        System.out.println(BOLD + "NÚMERO          TIPO              SALDO         TRANS." + RESET);
        System.out.println(BLUE + "─────────────────────────────────────────────────────────" + RESET);

        for (Cuenta cuenta : cuentas) {
            String numero = cuenta.getNumeroCuenta();
            String tipo = cuenta.getTipo();
            double saldo = cuenta.getSaldo();
            int transacciones = cuenta.getTransaccionesMes();

            System.out.printf("%-15s %-15s $%-12.2f %d%n",
                             numero, tipo, saldo, transacciones);
        }

        System.out.println(BLUE + "─────────────────────────────────────────────────────────" + RESET);
    }

    // ================================================================
    // UTILIDADES
    // ================================================================

    private static boolean validarClienteActivo() {
        if (clienteActual == null) {
            mostrarError("No hay un cliente activo. Por favor, cree un cliente primero (opción 1).");
            return false;
        }
        return true;
    }

    private static int leerOpcion() {
        try {
            String input = scanner.nextLine().trim();
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static void mostrarError(String mensaje) {
        System.out.println();
        System.out.println(RED + BOLD + "✗ ERROR: " + RESET + RED + mensaje + RESET);
        System.out.println();
    }

    private static void limpiarPantalla() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            // Si falla, imprimir líneas en blanco
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }

    private static void pausar() {
        System.out.println();
        System.out.print(CYAN + "Presione ENTER para continuar..." + RESET);
        scanner.nextLine();
    }

    private static void mostrarDespedida() {
        limpiarPantalla();
        System.out.println();
        System.out.println(BLUE + BOLD + "═══════════════════════════════════════════════════════════════" + RESET);
        System.out.println(GREEN + BOLD + "        ¡Gracias por usar el Sistema de Cuentas Bancarias!     " + RESET);
        System.out.println(BLUE + BOLD + "═══════════════════════════════════════════════════════════════" + RESET);
        System.out.println();
    }
}
