/*package edu.eam.ingesoft.fundamentos.cuentabancaria.gui;

import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cliente;
import edu.eam.ingesoft.fundamentos.cuentabancaria.logica.Cuenta;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/**
 * Interfaz gráfica para gestionar clientes y sus cuentas bancarias.
 * Permite crear clientes, abrir/cerrar cuentas, realizar operaciones.
 */
/*public class ClienteGUI extends JFrame {

    // Colores corporativos
    private static final Color COLOR_PRIMARY = new Color(41, 128, 185);      // Azul
    private static final Color COLOR_SUCCESS = new Color(39, 174, 96);       // Verde
    private static final Color COLOR_DANGER = new Color(231, 76, 60);        // Rojo
    private static final Color COLOR_WARNING = new Color(243, 156, 18);      // Naranja
    private static final Color COLOR_BACKGROUND = new Color(236, 240, 241);  // Gris claro
    private static final Color COLOR_TEXT = new Color(44, 62, 80);           // Gris oscuro

    // Formato de moneda
    private static final DecimalFormat MONEY_FORMAT = new DecimalFormat("$#,##0.00");

    // Cliente actual
    private Cliente clienteActual;

    // Componentes de interfaz
    private JTextField txtNombre, txtCedula, txtNumeroCuenta, txtMonto, txtCuentaOperacion;
    private JComboBox<String> cmbTipoCuenta, cmbTipoOperacion;
    private JTextArea txtResultados;
    private JLabel lblTotalCuentas, lblCuentasCorrientes, lblEstadoCliente, lblTransaccionesTotales;

    public ClienteGUI() {
        initComponents();
        setTitle("🏦 Sistema de Gestión de Cuentas Bancarias - BancoSeguro");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void initComponents() {
        // Panel principal con padding
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(COLOR_BACKGROUND);
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Panel superior: Creación de cliente
        mainPanel.add(crearPanelCliente(), BorderLayout.NORTH);

        // Panel central: Gestión de cuentas y operaciones
        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        centerPanel.setBackground(COLOR_BACKGROUND);
        centerPanel.add(crearPanelGestionCuentas());
        centerPanel.add(crearPanelOperaciones());
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Panel inferior: Resultados
        mainPanel.add(crearPanelResultados(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel crearPanelCliente() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARY, 2),
                new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitulo = new JLabel("CREAR CLIENTE");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(COLOR_PRIMARY);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        panel.add(lblTitulo, gbc);

        // Nombre
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        txtNombre = new JTextField(25);
        panel.add(txtNombre, gbc);

        // Cédula
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Cédula:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        txtCedula = new JTextField(25);
        panel.add(txtCedula, gbc);

        // Botón crear cliente
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 4;
        JButton btnCrearCliente = crearBoton("Crear Cliente", COLOR_PRIMARY);
        btnCrearCliente.addActionListener(e -> crearCliente());
        panel.add(btnCrearCliente, gbc);

        return panel;
    }

    private JPanel crearPanelGestionCuentas() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_SUCCESS, 2),
                new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitulo = new JLabel("GESTIÓN DE CUENTAS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(COLOR_SUCCESS);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        panel.add(lblTitulo, gbc);

        // Número de cuenta
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Número:"), gbc);

        gbc.gridx = 1;
        txtNumeroCuenta = new JTextField(10);
        panel.add(txtNumeroCuenta, gbc);

        // Tipo de cuenta
        gbc.gridx = 2;
        panel.add(new JLabel("Tipo:"), gbc);

        gbc.gridx = 3;
        cmbTipoCuenta = new JComboBox<>(new String[]{Cuenta.TIPO_AHORROS, Cuenta.TIPO_CORRIENTE});
        panel.add(cmbTipoCuenta, gbc);

        // Botones
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton btnAbrirCuenta = crearBoton("Abrir Cuenta", COLOR_SUCCESS);
        btnAbrirCuenta.addActionListener(e -> abrirCuenta());
        panel.add(btnAbrirCuenta, gbc);

        gbc.gridx = 2;
        JButton btnCerrarCuenta = crearBoton("Cerrar Cuenta", COLOR_DANGER);
        btnCerrarCuenta.addActionListener(e -> cerrarCuenta());
        panel.add(btnCerrarCuenta, gbc);

        // Panel de estadísticas
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 4;
        panel.add(crearPanelEstadisticas(), gbc);

        return panel;
    }

    private JPanel crearPanelEstadisticas() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 5));
        panel.setBackground(COLOR_BACKGROUND);
        panel.setBorder(new EmptyBorder(10, 0, 0, 0));

        lblTotalCuentas = crearEtiquetaEstadistica("Total Cuentas: 0");
        lblCuentasCorrientes = crearEtiquetaEstadistica("Corrientes: 0");
        lblEstadoCliente = crearEtiquetaEstadistica("Estado: N/A");
        lblTransaccionesTotales = crearEtiquetaEstadistica("Transacciones: 0");

        panel.add(lblTotalCuentas);
        panel.add(lblCuentasCorrientes);
        panel.add(lblEstadoCliente);
        panel.add(lblTransaccionesTotales);

        return panel;
    }

    private JLabel crearEtiquetaEstadistica(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Arial", Font.BOLD, 12));
        label.setForeground(COLOR_TEXT);
        label.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PRIMARY, 1),
                new EmptyBorder(5, 5, 5, 5)
        ));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(Color.WHITE);
        return label;
    }

    private JPanel crearPanelOperaciones() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_WARNING, 2),
                new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel lblTitulo = new JLabel("OPERACIONES BANCARIAS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitulo.setForeground(COLOR_WARNING);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        panel.add(lblTitulo, gbc);

        // Número de cuenta
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Cuenta:"), gbc);

        gbc.gridx = 1;
        txtCuentaOperacion = new JTextField(10);
        panel.add(txtCuentaOperacion, gbc);

        // Tipo de operación
        gbc.gridx = 2;
        panel.add(new JLabel("Operación:"), gbc);

        gbc.gridx = 3;
        cmbTipoOperacion = new JComboBox<>(new String[]{"Consignar", "Retirar"});
        panel.add(cmbTipoOperacion, gbc);

        // Monto
        gbc.gridy = 2;
        gbc.gridx = 0;
        panel.add(new JLabel("Monto:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        txtMonto = new JTextField(20);
        panel.add(txtMonto, gbc);

        // Botones
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JButton btnRealizarOperacion = crearBoton("Realizar Operación", COLOR_WARNING);
        btnRealizarOperacion.addActionListener(e -> realizarOperacion());
        panel.add(btnRealizarOperacion, gbc);

        gbc.gridx = 2;
        JButton btnMostrarResumen = crearBoton("Ver Resumen", COLOR_PRIMARY);
        btnMostrarResumen.addActionListener(e -> mostrarResumen());
        panel.add(btnMostrarResumen, gbc);

        return panel;
    }

    private JPanel crearPanelResultados() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(COLOR_BACKGROUND);

        JLabel lblTitulo = new JLabel("RESULTADOS Y RESUMEN");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        lblTitulo.setForeground(COLOR_TEXT);
        panel.add(lblTitulo, BorderLayout.NORTH);

        txtResultados = new JTextArea(8, 50);
        txtResultados.setEditable(false);
        txtResultados.setFont(new Font("Courier New", Font.PLAIN, 12));
        txtResultados.setBackground(Color.WHITE);
        txtResultados.setBorder(BorderFactory.createLineBorder(COLOR_TEXT, 1));

        JScrollPane scroll = new JScrollPane(txtResultados);
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    private JButton crearBoton(String texto, Color color) {
        JButton boton = new JButton(texto);
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Arial", Font.BOLD, 12));
        boton.setFocusPainted(false);
        boton.setBorder(new EmptyBorder(8, 15, 8, 15));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efecto hover
        boton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                boton.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                boton.setBackground(color);
            }
        });

        return boton;
    }

    // ===== MÉTODOS DE LÓGICA =====

    private void crearCliente() {
        String nombre = txtNombre.getText().trim();
        String cedula = txtCedula.getText().trim();

        if (nombre.isEmpty() || cedula.isEmpty()) {
            mostrarError("Debe ingresar nombre y cédula");
            return;
        }

        clienteActual = new Cliente(nombre, cedula);
        txtResultados.setText("✓ Cliente creado exitosamente:\n" +
                "Nombre: " + nombre + "\n" +
                "Cédula: " + cedula + "\n\n" +
                "Ahora puede abrir cuentas y realizar operaciones.");

        actualizarEstadisticas();
        mostrarExito("Cliente creado exitosamente");
    }

    private void abrirCuenta() {
        if (clienteActual == null) {
            mostrarError("Debe crear un cliente primero");
            return;
        }

        String numeroCuenta = txtNumeroCuenta.getText().trim();
        String tipo = (String) cmbTipoCuenta.getSelectedItem();

        if (numeroCuenta.isEmpty()) {
            mostrarError("Debe ingresar un número de cuenta");
            return;
        }

        boolean exito = clienteActual.abrirCuenta(numeroCuenta, tipo);

        if (exito) {
            txtResultados.setText("✓ Cuenta abierta exitosamente:\n" +
                    "Número: " + numeroCuenta + "\n" +
                    "Tipo: " + tipo + "\n" +
                    "Saldo inicial: $0.00\n\n" +
                    "Total de cuentas: " + clienteActual.contarCuentas());

            txtNumeroCuenta.setText("");
            actualizarEstadisticas();
            mostrarExito("Cuenta abierta exitosamente");
        } else {
            String mensaje = tipo.equals(Cuenta.TIPO_CORRIENTE) &&
                    clienteActual.contarCuentasCorrientes() >= Cliente.MAX_CUENTAS_CORRIENTES ?
                    "Ya tiene el máximo de cuentas corrientes (3)" :
                    "Ya tiene el máximo de cuentas permitidas (6)";
            mostrarError(mensaje);
        }
    }

    private void cerrarCuenta() {
        if (clienteActual == null) {
            mostrarError("Debe crear un cliente primero");
            return;
        }

        String numeroCuenta = txtNumeroCuenta.getText().trim();

        if (numeroCuenta.isEmpty()) {
            mostrarError("Debe ingresar un número de cuenta");
            return;
        }

        Cuenta cuenta = clienteActual.buscarCuenta(numeroCuenta);
        if (cuenta == null) {
            mostrarError("Cuenta no encontrada");
            return;
        }

        if (cuenta.getSaldo() != 0) {
            mostrarError("La cuenta debe tener saldo $0 para cerrarla.\n" +
                    "Saldo actual: " + MONEY_FORMAT.format(cuenta.getSaldo()));
            return;
        }

        boolean exito = clienteActual.cerrarCuenta(numeroCuenta);

        if (exito) {
            txtResultados.setText("✓ Cuenta cerrada exitosamente:\n" +
                    "Número: " + numeroCuenta + "\n\n" +
                    "Total de cuentas restantes: " + clienteActual.contarCuentas());

            txtNumeroCuenta.setText("");
            actualizarEstadisticas();
            mostrarExito("Cuenta cerrada exitosamente");
        }
    }

    private void realizarOperacion() {
        if (clienteActual == null) {
            mostrarError("Debe crear un cliente primero");
            return;
        }

        String numeroCuenta = txtCuentaOperacion.getText().trim();
        String montoStr = txtMonto.getText().trim();
        String operacion = (String) cmbTipoOperacion.getSelectedItem();

        if (numeroCuenta.isEmpty() || montoStr.isEmpty()) {
            mostrarError("Debe ingresar número de cuenta y monto");
            return;
        }

        double monto;
        try {
            monto = Double.parseDouble(montoStr);
            if (monto <= 0) {
                mostrarError("El monto debe ser mayor a cero");
                return;
            }
        } catch (NumberFormatException e) {
            mostrarError("Monto inválido");
            return;
        }

        Cuenta cuenta = clienteActual.buscarCuenta(numeroCuenta);
        if (cuenta == null) {
            mostrarError("Cuenta no encontrada");
            return;
        }

        double saldoAnterior = cuenta.getSaldo();
        int transaccionesAntes = cuenta.getTransaccionesMes();
        boolean exito;

        if (operacion.equals("Consignar")) {
            double cargo = cuenta.calcularCargoConsignacion(monto);
            exito = clienteActual.realizarConsignacion(numeroCuenta, monto);

            if (exito) {
                txtResultados.setText("✓ CONSIGNACIÓN EXITOSA\n\n" +
                        "Cuenta: " + numeroCuenta + " (" + cuenta.getTipo() + ")\n" +
                        "Monto consignado: " + MONEY_FORMAT.format(monto) + "\n" +
                        "Cargo aplicado: " + MONEY_FORMAT.format(cargo) + "\n" +
                        "Monto neto: " + MONEY_FORMAT.format(monto - cargo) + "\n\n" +
                        "Saldo anterior: " + MONEY_FORMAT.format(saldoAnterior) + "\n" +
                        "Saldo actual: " + MONEY_FORMAT.format(cuenta.getSaldo()) + "\n" +
                        "Transacciones: " + transaccionesAntes + " → " + cuenta.getTransaccionesMes());

                mostrarExito("Consignación exitosa");
            }
        } else { // Retirar
            double cargo = cuenta.calcularCargoRetiro(monto);
            exito = clienteActual.realizarRetiro(numeroCuenta, monto);

            if (exito) {
                txtResultados.setText("✓ RETIRO EXITOSO\n\n" +
                        "Cuenta: " + numeroCuenta + " (" + cuenta.getTipo() + ")\n" +
                        "Monto retirado: " + MONEY_FORMAT.format(monto) + "\n" +
                        "Cargo aplicado: " + MONEY_FORMAT.format(cargo) + "\n" +
                        "Total descontado: " + MONEY_FORMAT.format(monto + cargo) + "\n\n" +
                        "Saldo anterior: " + MONEY_FORMAT.format(saldoAnterior) + "\n" +
                        "Saldo actual: " + MONEY_FORMAT.format(cuenta.getSaldo()) + "\n" +
                        "Transacciones: " + transaccionesAntes + " → " + cuenta.getTransaccionesMes());

                mostrarExito("Retiro exitoso");
            } else {
                mostrarError("Saldo insuficiente.\n" +
                        "Saldo disponible: " + MONEY_FORMAT.format(saldoAnterior) + "\n" +
                        "Monto solicitado + cargo: " + MONEY_FORMAT.format(monto + cargo));
                return;
            }
        }

        txtMonto.setText("");
        actualizarEstadisticas();
    }

    private void mostrarResumen() {
        if (clienteActual == null) {
            mostrarError("Debe crear un cliente primero");
            return;
        }

        txtResultados.setText(clienteActual.mostrarResumen());
    }

    private void actualizarEstadisticas() {
        if (clienteActual != null) {
            lblTotalCuentas.setText("Total Cuentas: " + clienteActual.contarCuentas());
            lblCuentasCorrientes.setText("Corrientes: " + clienteActual.contarCuentasCorrientes());
            lblEstadoCliente.setText("Estado: " + clienteActual.determinarEstado());
            lblTransaccionesTotales.setText("Transacciones: " + clienteActual.contarTransaccionesTotales());

            // Colorear el estado
            String estado = clienteActual.determinarEstado();
            if (estado.equals(Cliente.ESTADO_VIP)) {
                lblEstadoCliente.setBackground(COLOR_SUCCESS);
                lblEstadoCliente.setForeground(Color.WHITE);
            } else if (estado.equals(Cliente.ESTADO_ACTIVO)) {
                lblEstadoCliente.setBackground(COLOR_WARNING);
                lblEstadoCliente.setForeground(Color.WHITE);
            } else {
                lblEstadoCliente.setBackground(Color.WHITE);
                lblEstadoCliente.setForeground(COLOR_TEXT);
            }
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarExito(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            ClienteGUI gui = new ClienteGUI();
            gui.setVisible(true);
        });
    }
}*/

