# Configuración de GitHub Codespaces

Este directorio contiene la configuración para GitHub Codespaces, que permite trabajar en el proyecto sin necesidad de instalar nada localmente.

## ¿Qué incluye esta configuración?

- **Java 17**: Versión LTS de Java requerida para el proyecto
- **Maven 3.9**: Herramienta de construcción y gestión de dependencias
- **Extensiones de VS Code**: Pack completo de extensiones para desarrollo Java
  - Java Extension Pack
  - Maven for Java
  - Language Support for Java (Red Hat)
  - Debugger for Java
  - Test Runner for Java
  - Java Dependency Viewer

## ¿Qué sucede al crear un Codespace?

1. Se crea un contenedor con Ubuntu + Java 17 + Maven
2. Se instalan automáticamente las extensiones de VS Code
3. Se ejecuta `mvn clean compile` para verificar que el proyecto compila
4. El entorno queda listo para trabajar

## Comandos útiles en Codespaces

Una vez dentro del Codespace, puedes usar:

```bash
# Compilar el proyecto
mvn clean compile

# Ejecutar tests
mvn test

# Ejecutar un test específico
mvn test -Dtest=CuentaTest#testConstructorAhorros

# Ejecutar el CLI
mvn clean compile exec:java -Dexec.mainClass="edu.eam.ingesoft.fundamentos.cuentabancaria.cli.ClienteCLI"
```

## Ventajas de usar Codespaces

✅ No necesitas instalar Java ni Maven localmente
✅ Entorno consistente para todos los estudiantes
✅ Funciona en cualquier dispositivo con navegador web
✅ Configuración automática, lista en minutos
✅ 60 horas gratis al mes para estudiantes con GitHub Student Developer Pack

## Nota

La configuración incluye el reenvío del puerto 8080 por si decides ejecutar una aplicación web en el futuro.
