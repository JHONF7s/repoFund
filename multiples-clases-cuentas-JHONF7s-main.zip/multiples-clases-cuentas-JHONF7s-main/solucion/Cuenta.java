package edu.eam.ingesoft.fundamentos.cuentabancaria.logica;

/**
 * Clase que representa una cuenta bancaria.
 * Puede ser de tipo AHORROS o CORRIENTE.
 * Gestiona operaciones de retiro y consignación con sus respectivos cargos.
 *
 * VERSIÓN SOLUCIÓN - IMPLEMENTACIÓN COMPLETA
 */
public class Cuenta {

    // Constantes para los tipos de cuenta
    public static final String TIPO_AHORROS = "AHORROS";
    public static final String TIPO_CORRIENTE = "CORRIENTE";

    // Constantes para las reglas de negocio de AHORROS
    public static final int TRANSACCIONES_GRATIS_RETIRO_AHORROS = 3;
    public static final double CARGO_RETIRO_AHORROS = 0.01; // 1%

    // Constantes para las reglas de negocio de CORRIENTE
    public static final int TRANSACCIONES_GRATIS_RETIRO_CORRIENTE = 5;
    public static final double CARGO_RETIRO_CORRIENTE = 0.02; // 2%
    public static final int TRANSACCIONES_GRATIS_CONSIGNACION_CORRIENTE = 4;
    public static final double CARGO_CONSIGNACION_CORRIENTE = 0.01; // 1%

    // Atributos de la cuenta
    private String numeroCuenta;
    private String tipo;
    private double saldo;
    private int transaccionesMes;

    /**
     * Constructor de la clase Cuenta.
     * @param numeroCuenta Número identificador de la cuenta
     * @param tipo Tipo de cuenta: AHORROS o CORRIENTE
     */
    public Cuenta(String numeroCuenta, String tipo) {
        this.numeroCuenta = numeroCuenta;
        this.tipo = tipo;
        this.saldo = 0.0;
        this.transaccionesMes = 0;
    }

    /**
     * Realiza un retiro de la cuenta.
     * Debe validar que haya saldo suficiente para el retiro + el cargo.
     * Debe aplicar cargos según el tipo de cuenta y número de transacciones.
     *
     * @param monto Monto a retirar
     * @return true si el retiro fue exitoso, false si fue rechazado
     */
    public boolean retirar(double monto) {
        // Calcular el cargo por retiro
        double cargo = calcularCargoRetiro(monto);
        double totalRequerido = monto + cargo;

        // Validar que haya saldo suficiente
        if (saldo < totalRequerido) {
            return false; // Saldo insuficiente
        }

        // Realizar el retiro
        saldo -= totalRequerido;
        transaccionesMes++;
        return true;
    }

    /**
     * Realiza una consignación (depósito) en la cuenta.
     * Para ahorros no tiene cargo.
     * Para corriente cobra 1% a partir de la 5ta transacción.
     *
     * @param monto Monto a consignar
     * @return true si la consignación fue exitosa
     */
    public boolean consignar(double monto) {
        // Calcular el cargo por consignación
        double cargo = calcularCargoConsignacion(monto);
        double montoNeto = monto - cargo;

        // Realizar la consignación
        saldo += montoNeto;
        transaccionesMes++;
        return true;
    }

    /**
     * Calcula el cargo por realizar un retiro.
     * Depende del tipo de cuenta y el número de transacciones del mes.
     *
     * @param monto Monto que se va a retirar
     * @return El cargo a aplicar
     */
    public double calcularCargoRetiro(double monto) {
        if (tipo.equals(TIPO_AHORROS)) {
            // Para ahorros: cargo 1% a partir de la 4ta transacción
            if (transaccionesMes >= TRANSACCIONES_GRATIS_RETIRO_AHORROS) {
                return monto * CARGO_RETIRO_AHORROS;
            }
        } else if (tipo.equals(TIPO_CORRIENTE)) {
            // Para corriente: cargo 2% a partir de la 6ta transacción
            if (transaccionesMes >= TRANSACCIONES_GRATIS_RETIRO_CORRIENTE) {
                return monto * CARGO_RETIRO_CORRIENTE;
            }
        }
        return 0.0;
    }

    /**
     * Calcula el cargo por realizar una consignación.
     * Depende del tipo de cuenta y el número de transacciones del mes.
     *
     * @param monto Monto que se va a consignar
     * @return El cargo a aplicar
     */
    public double calcularCargoConsignacion(double monto) {
        if (tipo.equals(TIPO_AHORROS)) {
            // Para ahorros: consignaciones siempre gratis
            return 0.0;
        } else if (tipo.equals(TIPO_CORRIENTE)) {
            // Para corriente: cargo 1% a partir de la 5ta transacción
            if (transaccionesMes >= TRANSACCIONES_GRATIS_CONSIGNACION_CORRIENTE) {
                return monto * CARGO_CONSIGNACION_CORRIENTE;
            }
        }
        return 0.0;
    }

    /**
     * Genera una cadena con la información de la cuenta.
     * @return String formateado con los datos de la cuenta
     */
    public String mostrarInformacion() {
        return String.format("Cuenta #%s - Tipo: %s - Saldo: $%.2f - Transacciones: %d",
                numeroCuenta, tipo, saldo, transaccionesMes);
    }

    // Getters y Setters
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getTransaccionesMes() {
        return transaccionesMes;
    }

    public void setTransaccionesMes(int transaccionesMes) {
        this.transaccionesMes = transaccionesMes;
    }
}
