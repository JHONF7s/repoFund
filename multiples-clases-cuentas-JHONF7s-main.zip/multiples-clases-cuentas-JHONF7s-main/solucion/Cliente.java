package edu.eam.ingesoft.fundamentos.cuentabancaria.logica;

import java.util.ArrayList;

/**
 * Clase que representa un cliente del banco.
 * Un cliente puede tener hasta 6 cuentas, máximo 3 corrientes.
 * Gestiona operaciones sobre múltiples cuentas usando ArrayList.
 *
 * VERSIÓN SOLUCIÓN - IMPLEMENTACIÓN COMPLETA CON ARRAYLIST
 */
public class Cliente {

    // Constantes para límites
    public static final int MAX_CUENTAS = 6;
    public static final int MAX_CUENTAS_CORRIENTES = 3;

    // Constantes para estados del cliente
    public static final String ESTADO_INACTIVO = "INACTIVO";
    public static final String ESTADO_ACTIVO = "ACTIVO";
    public static final String ESTADO_VIP = "VIP";

    // Límites de transacciones para estados
    public static final int LIMITE_INACTIVO = 5;
    public static final int LIMITE_VIP = 20;

    // Atributos del cliente
    private String nombre;
    private String cedula;

    // Lista de cuentas del cliente
    private ArrayList<Cuenta> cuentas;

    /**
     * Constructor de la clase Cliente.
     * @param nombre Nombre completo del cliente
     * @param cedula Cédula del cliente (identificador único)
     */
    public Cliente(String nombre, String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.cuentas = new ArrayList<>();
    }

    /**
     * Abre una nueva cuenta para el cliente.
     * Valida que no se excedan los límites de cuentas totales y corrientes.
     *
     * @param numeroCuenta Número de la nueva cuenta
     * @param tipo Tipo de cuenta: AHORROS o CORRIENTE
     * @return true si se abrió exitosamente, false si se rechazó
     */
    public boolean abrirCuenta(String numeroCuenta, String tipo) {
        // Validar límite de cuentas totales
        if (contarCuentas() >= MAX_CUENTAS) {
            return false; // Ya tiene el máximo de cuentas
        }

        // Si es corriente, validar límite de corrientes
        if (tipo.equals(Cuenta.TIPO_CORRIENTE)) {
            if (contarCuentasCorrientes() >= MAX_CUENTAS_CORRIENTES) {
                return false; // Ya tiene el máximo de cuentas corrientes
            }
        }

        // Crear y agregar la cuenta
        Cuenta nuevaCuenta = new Cuenta(numeroCuenta, tipo);
        cuentas.add(nuevaCuenta);
        return true;
    }

    /**
     * Cierra una cuenta del cliente.
     * Solo se puede cerrar si el saldo es exactamente $0.
     *
     * @param numeroCuenta Número de la cuenta a cerrar
     * @return true si se cerró exitosamente, false si no
     */
    public boolean cerrarCuenta(String numeroCuenta) {
        // Buscar la cuenta
        Cuenta cuenta = buscarCuenta(numeroCuenta);

        // Validar que existe y que su saldo es 0
        if (cuenta == null || cuenta.getSaldo() != 0.0) {
            return false;
        }

        // Remover la cuenta de la lista
        cuentas.remove(cuenta);
        return true;
    }

    /**
     * Realiza un retiro en una cuenta específica del cliente.
     *
     * @param numeroCuenta Número de la cuenta
     * @param monto Monto a retirar
     * @return true si el retiro fue exitoso, false si no
     */
    public boolean realizarRetiro(String numeroCuenta, double monto) {
        Cuenta cuenta = buscarCuenta(numeroCuenta);
        if (cuenta != null) {
            return cuenta.retirar(monto);
        }
        return false;
    }

    /**
     * Realiza una consignación en una cuenta específica del cliente.
     *
     * @param numeroCuenta Número de la cuenta
     * @param monto Monto a consignar
     * @return true si la consignación fue exitosa
     */
    public boolean realizarConsignacion(String numeroCuenta, double monto) {
        Cuenta cuenta = buscarCuenta(numeroCuenta);
        if (cuenta != null) {
            return cuenta.consignar(monto);
        }
        return false;
    }

    /**
     * Cuenta el número total de cuentas del cliente.
     * @return Número de cuentas (0-6)
     */
    public int contarCuentas() {
        return cuentas.size();
    }

    /**
     * Cuenta el número de cuentas corrientes del cliente.
     * @return Número de cuentas corrientes (0-3)
     */
    public int contarCuentasCorrientes() {
        int contador = 0;
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getTipo().equals(Cuenta.TIPO_CORRIENTE)) {
                contador++;
            }
        }
        return contador;
    }

    /**
     * Suma las transacciones de todas las cuentas del cliente.
     * @return Total de transacciones en el mes
     */
    public int contarTransaccionesTotales() {
        int total = 0;
        for (Cuenta cuenta : cuentas) {
            total += cuenta.getTransaccionesMes();
        }
        return total;
    }

    /**
     * Determina el estado del cliente según su actividad transaccional.
     * @return INACTIVO, ACTIVO o VIP
     */
    public String determinarEstado() {
        int totalTransacciones = contarTransaccionesTotales();

        if (totalTransacciones < LIMITE_INACTIVO) {
            return ESTADO_INACTIVO;
        } else if (totalTransacciones <= LIMITE_VIP) {
            return ESTADO_ACTIVO;
        } else {
            return ESTADO_VIP;
        }
    }

    /**
     * Busca una cuenta por su número.
     * @param numeroCuenta Número de cuenta a buscar
     * @return La cuenta si existe, null si no
     */
    public Cuenta buscarCuenta(String numeroCuenta) {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                return cuenta;
            }
        }
        return null;
    }

    /**
     * Genera un resumen completo del cliente con todas sus cuentas.
     * @return String formateado con la información del cliente
     */
    public String mostrarResumen() {
        StringBuilder resumen = new StringBuilder();
        resumen.append("=== RESUMEN DEL CLIENTE ===\n");
        resumen.append(String.format("Nombre: %s\n", nombre));
        resumen.append(String.format("Cédula: %s\n", cedula));
        resumen.append(String.format("Total de cuentas: %d\n", contarCuentas()));
        resumen.append(String.format("Estado: %s\n", determinarEstado()));
        resumen.append("\nCUENTAS:\n");

        for (Cuenta cuenta : cuentas) {
            resumen.append(cuenta.mostrarInformacion()).append("\n");
        }

        return resumen.toString();
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }

    public void setCuentas(ArrayList<Cuenta> cuentas) {
        this.cuentas = cuentas;
    }
}
