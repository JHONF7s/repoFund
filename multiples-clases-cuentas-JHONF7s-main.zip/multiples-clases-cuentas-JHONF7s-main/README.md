[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/gOkX9ePO)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21587663)
# 🏦 Sistema de Gestión de Cuentas Bancarias

## 📚 Objetivos del Ejercicio

Al completar este ejercicio, serás capaz de:

1. **Diseñar y trabajar con múltiples clases relacionadas** que interactúan entre sí (Cliente y Cuenta)
2. **Implementar lógica de negocio compleja** con validaciones, cálculos de comisiones y restricciones
3. **Aplicar estructuras de decisión anidadas** para resolver problemas del mundo real
4. **Usar ArrayList para manejar colecciones de objetos** (lista de cuentas)
5. **Recorrer listas con for-each** para buscar, contar y procesar elementos
6. **Validar reglas de negocio** con múltiples condiciones y estados

---

## 🎯 Contexto del Negocio

El banco **"BancoSeguro"** necesita un sistema para administrar las cuentas bancarias de sus clientes. Cada cliente puede tener múltiples cuentas con diferentes características y cada operación tiene costos específicos según el tipo de cuenta y el número de transacciones realizadas en el mes.

---

## 📋 Reglas del Negocio

### 1. Cliente
- Cada cliente tiene un **nombre** y una **cédula** (identificador único)
- Un cliente puede tener hasta **6 cuentas** en total
- De esas 6 cuentas, máximo **3 pueden ser cuentas corrientes**
- El resto pueden ser cuentas de ahorros

### 2. Cuenta Bancaria
Cada cuenta tiene:
- **Número de cuenta** (identificador único)
- **Tipo**: Ahorros o Corriente
- **Saldo actual**
- **Número de transacciones mensuales** (contador que se reinicia cada mes)

### 3. Operación de Retiro
- **NO se puede retirar más del saldo disponible** (el saldo no puede quedar negativo)
- **Cuenta de Ahorros**:
  - Las primeras 3 transacciones del mes son gratuitas
  - A partir de la transacción número 4, se cobra un **1% del monto retirado**
- **Cuenta Corriente**:
  - Las primeras 5 transacciones del mes son gratuitas
  - A partir de la transacción número 6, se cobra un **2% del monto retirado**

### 4. Operación de Consignación (Depósito)
- **Cuenta de Ahorros**:
  - Todas las consignaciones son **gratuitas**
  - No hay límite de transacciones sin costo
- **Cuenta Corriente**:
  - Las primeras 4 transacciones del mes son gratuitas
  - A partir de la transacción número 5, se cobra un **1% del monto consignado**

### 5. Apertura de Cuentas
- El cliente puede abrir nuevas cuentas siempre que:
  - No tenga ya 6 cuentas en total
  - Si es cuenta corriente, no tenga ya 3 cuentas corrientes
- La cuenta nueva se abre con saldo $0

### 6. Cierre de Cuentas
- Una cuenta solo puede cerrarse si **su saldo es exactamente $0**
- Al cerrar una cuenta, se elimina del registro del cliente

### 7. Estado del Cliente según Actividad
- **Inactivo**: Tiene menos de 5 transacciones totales en el mes (sumando todas sus cuentas)
- **Activo**: Tiene entre 5 y 20 transacciones totales en el mes
- **VIP**: Tiene más de 20 transacciones totales en el mes

---

## 🎓 Objetivo 1: Identificación de Datos

Antes de programar, debes identificar los atributos y métodos necesarios para cada clase.

### Clase Cuenta

| Tipo de Dato | Nombre del Atributo | Descripción |
|--------------|---------------------|-------------|
| String       | numeroCuenta        | Identificador único de la cuenta |
| String       | tipo                | "AHORROS" o "CORRIENTE" |
| double       | saldo               | Saldo actual de la cuenta |
| int          | transaccionesMes    | Contador de transacciones del mes |

**Métodos Necesarios para la Clase Cuenta:**

| Nombre del Método | Descripción |
|-------------------|-------------|
| `Cuenta(String numeroCuenta, String tipo)` | Constructor que inicializa una cuenta |
| `boolean retirar(double monto)` | Realiza un retiro con validaciones y cargos |
| `boolean consignar(double monto)` | Realiza una consignación con validaciones y cargos |
| `double calcularCargoRetiro(double monto)` | Calcula el cargo por retiro según reglas |
| `double calcularCargoConsignacion(double monto)` | Calcula el cargo por consignación según reglas |
| `String mostrarInformacion()` | Retorna información detallada de la cuenta |
| getters y setters | Para todos los atributos |

### Clase Cliente

| Tipo de Dato | Nombre del Atributo | Descripción |
|--------------|---------------------|-------------|
| String       | nombre              | Nombre completo del cliente |
| String       | cedula              | Cédula del cliente (identificador único) |
| ArrayList<Cuenta> | cuentas        | Lista de cuentas del cliente (máximo 6) |

**Métodos Necesarios para la Clase Cliente:**

| Nombre del Método | Descripción |
|-------------------|-------------|
| `Cliente(String nombre, String cedula)` | Constructor que inicializa el cliente |
| `boolean abrirCuenta(String numeroCuenta, String tipo)` | Abre una nueva cuenta validando restricciones |
| `boolean cerrarCuenta(String numeroCuenta)` | Cierra una cuenta si cumple condiciones |
| `boolean realizarRetiro(String numeroCuenta, double monto)` | Busca la cuenta y realiza el retiro |
| `boolean realizarConsignacion(String numeroCuenta, double monto)` | Busca la cuenta y realiza la consignación |
| `int contarCuentas()` | Retorna el número total de cuentas |
| `int contarCuentasCorrientes()` | Retorna el número de cuentas corrientes |
| `int contarTransaccionesTotales()` | Suma transacciones de todas las cuentas |
| `String determinarEstado()` | Retorna el estado del cliente según actividad |
| `Cuenta buscarCuenta(String numeroCuenta)` | Busca y retorna una cuenta por su número |
| `String mostrarResumen()` | Retorna resumen completo del cliente |
| getters y setters | Para todos los atributos |

---

## 📝 Objetivo 2: Situaciones para Resolver en Papel

Antes de implementar en código, resuelve estas situaciones **manualmente en papel**. Esto te ayudará a entender la lógica del negocio.

### Situación 1: Retiro con Cargo en Cuenta de Ahorros
**Datos:**
- Cliente: María Rodríguez (Cédula: 1234567890)
- Cuenta de Ahorros #001
- Saldo inicial: $500,000
- Transacciones del mes: 3

**Operación:** Retirar $100,000

**Preguntas:**
1. ¿Se cobra cargo por este retiro? ¿Por qué?
2. ¿Cuánto es el cargo?
3. ¿Cuál es el nuevo saldo?
4. ¿Cuántas transacciones tiene la cuenta ahora?

---

### Situación 2: Consignación con Cargo en Cuenta Corriente
**Datos:**
- Cliente: Carlos Gómez (Cédula: 9876543210)
- Cuenta Corriente #002
- Saldo inicial: $1,200,000
- Transacciones del mes: 5

**Operación:** Consignar $300,000

**Preguntas:**
1. ¿Se cobra cargo por esta consignación? ¿Por qué?
2. ¿Cuánto es el cargo?
3. ¿Cuál es el monto neto consignado?
4. ¿Cuál es el nuevo saldo?

---

### Situación 3: Intento de Retiro que Excede el Saldo
**Datos:**
- Cliente: Ana López (Cédula: 5555555555)
- Cuenta de Ahorros #003
- Saldo actual: $50,000
- Transacciones del mes: 1

**Operación:** Retirar $60,000

**Preguntas:**
1. ¿Se puede realizar este retiro? ¿Por qué?
2. ¿Qué mensaje debe mostrar el sistema?

---

### Situación 4: Apertura de Cuenta con Validación
**Datos:**
- Cliente: Pedro Sánchez (Cédula: 7777777777)
- Cuentas actuales: 2 de ahorros, 2 corrientes (4 total)

**Operación:** Abrir una nueva cuenta corriente (#005)

**Preguntas:**
1. ¿Se puede abrir esta cuenta? Justifica con las reglas de negocio
2. ¿Cuál sería el estado final del cliente?

---

### Situación 5: Intento de Cierre de Cuenta con Saldo
**Datos:**
- Cliente: Laura Méndez (Cédula: 4444444444)
- Cuenta Corriente #007
- Saldo actual: $5,000

**Operación:** Cerrar la cuenta #007

**Preguntas:**
1. ¿Se puede cerrar esta cuenta? ¿Por qué?
2. ¿Qué debe hacer el cliente antes de cerrar la cuenta?

---

### Situación 6: Determinación de Estado del Cliente
**Datos:**
- Cliente: Roberto Díaz (Cédula: 8888888888)
- Cuenta 1 (Ahorros): 8 transacciones
- Cuenta 2 (Corriente): 7 transacciones
- Cuenta 3 (Ahorros): 3 transacciones

**Preguntas:**
1. ¿Cuántas transacciones totales tiene el cliente?
2. ¿Cuál es su estado (Inactivo/Activo/VIP)?

---

### Situación 7: Múltiples Operaciones Secuenciales
**Datos:**
- Cliente: Sandra Torres (Cédula: 2222222222)
- Cuenta Corriente #008
- Saldo inicial: $0
- Transacciones del mes: 0

**Operaciones:**
1. Consignar $1,000,000
2. Consignar $500,000
3. Consignar $300,000
4. Consignar $200,000
5. Consignar $100,000 (5ta consignación)
6. Retirar $50,000 (6ta transacción)

**Preguntas:**
1. Calcula el saldo después de cada operación
2. Identifica cuáles operaciones tuvieron cargo
3. ¿Cuál es el saldo final?
4. ¿Cuánto se cobró en total por comisiones?

---

### Situación 8: Intento de Apertura Excediendo Límites
**Datos:**
- Cliente: Luis Martínez (Cédula: 3333333333)
- Cuentas actuales: 2 de ahorros, 3 corrientes (5 total)

**Operación:** Abrir una nueva cuenta corriente

**Preguntas:**
1. ¿Se puede abrir esta cuenta? ¿Por qué?
2. ¿Qué tipo de cuenta sí podría abrir el cliente?
3. ¿Cuántas cuentas más puede abrir en total?

---

## 💻 Objetivo 3: Implementación en Java

### Instrucciones de Implementación

Debes completar la implementación de las clases `Cuenta` y `Cliente` en el paquete `edu.eam.ingesoft.fundamentos.cuentabancaria.logica`.

**IMPORTANTE:**
- El proyecto ya tiene la estructura de las clases con métodos vacíos
- Debes completar la lógica de cada método
- NO modifiques las firmas de los métodos (nombres, parámetros, tipo de retorno)
- Usa estructuras de decisión (if, else if, else, switch)
- Usa ArrayList para manejar las cuentas del cliente
- Practica el uso de for-each para recorrer la lista

### Consideraciones Técnicas

1. **Manejo de las cuentas en Cliente:**
   - Usa un `ArrayList<Cuenta>` para almacenar las cuentas
   - El ArrayList se inicializa vacío en el constructor
   - Para agregar una cuenta, usa `cuentas.add(nuevaCuenta)`
   - Para buscar una cuenta, recorre el ArrayList con un for-each
   - Para eliminar una cuenta, usa `cuentas.remove(cuenta)`
   - Para contar cuentas, usa `cuentas.size()`

2. **Cálculo de Cargos:**
   - Verifica el tipo de cuenta (AHORROS o CORRIENTE)
   - Cuenta las transacciones del mes
   - Aplica los porcentajes según las reglas

3. **Validaciones:**
   - Siempre valida que el saldo sea suficiente
   - Valida que no se excedan los límites de cuentas
   - Valida que el saldo sea $0 antes de cerrar

---

## 🚀 Comandos para Ejecutar

### Compilar el proyecto
```bash
mvn clean compile
```

### Ejecutar todas las pruebas
```bash
mvn test
```

### Ejecutar la interfaz gráfica (GUI)
```bash
mvn clean compile exec:java -Dexec.mainClass="edu.eam.ingesoft.fundamentos.cuentabancaria.gui.ClienteGUI"
```

### Ejecutar la interfaz CLI interactiva (RECOMENDADO)
```bash
mvn clean compile exec:java -Dexec.mainClass="edu.eam.ingesoft.fundamentos.cuentabancaria.cli.ClienteCLI"
```

### Ejecutar la aplicación de consola (casos de demostración)
```bash
mvn clean compile exec:java -Dexec.mainClass="org.example.Main"
```

---

## ✅ Criterios de Éxito

Tu implementación será exitosa cuando:

1. **Todos los tests pasen al 100%** - El proyecto incluye 25+ tests que validan cada funcionalidad
2. **La GUI funcione correctamente** - Puedes crear clientes, abrir cuentas, realizar operaciones
3. **GitHub Actions esté en verde** - El workflow automático compila y ejecuta los tests
4. **El código siga las reglas de negocio** - Validaciones correctas, cálculos precisos

### Distribución de Puntos (100 total)

- Compilación exitosa: 10 puntos
- Tests de clase Cuenta (retiros, consignaciones, cargos): 30 puntos
- Tests de clase Cliente (apertura, cierre, búsqueda): 30 puntos
- Tests de integración (múltiples operaciones): 20 puntos
- Suite completa de tests: 10 puntos

---

## 📖 Pasos para Comenzar

1. **Clona el repositorio** de GitHub Classroom
2. **Abre el proyecto** en IntelliJ IDEA
3. **Resuelve las situaciones en papel** (Objetivo 2)
4. **Revisa las clases** en `src/main/java/.../logica/`
5. **Completa los métodos vacíos** siguiendo la lógica del negocio
6. **Ejecuta los tests** con `mvn test` para verificar tu progreso
7. **Prueba la GUI** para ver tu implementación en acción
8. **Haz commit y push** cuando completes cada funcionalidad

---

## 🛠️ Estructura del Proyecto

```
proyecto/
├── src/
│   ├── main/
│   │   └── java/
│   │       ├── edu/eam/ingesoft/fundamentos/cuentabancaria/
│   │       │   ├── logica/
│   │       │   │   ├── Cuenta.java           ← COMPLETA ESTA CLASE
│   │       │   │   └── Cliente.java          ← COMPLETA ESTA CLASE
│   │       │   ├── gui/
│   │       │   │   └── ClienteGUI.java       (Interfaz gráfica Swing)
│   │       │   └── cli/
│   │       │       └── ClienteCLI.java       (Interfaz CLI interactiva)
│   │       └── org/example/
│   │           └── Main.java                 (Casos de demostración)
│   └── test/
│       └── java/
│           └── edu/eam/ingesoft/fundamentos/cuentabancaria/
│               ├── CuentaTest.java           (Tests para Cuenta)
│               └── ClienteTest.java          (Tests para Cliente)
├── pom.xml                                   (Configuración Maven)
└── README.md                                 (Este archivo)
```

---

## 💡 Consejos

1. **Lee todas las reglas de negocio** antes de empezar a codificar
2. **Resuelve primero en papel** para entender la lógica
3. **Implementa método por método** y prueba cada uno
4. **Ejecuta los tests frecuentemente** para detectar errores temprano
5. **Usa la GUI** para probar casos que no están en los tests
6. **Lee los mensajes de error** de los tests, te indican qué está fallando
7. **No te saltes las validaciones**, son cruciales para el negocio

---

## 📞 Soporte

Si tienes dudas sobre:
- **Reglas de negocio**: Revisa la sección "Reglas del Negocio"
- **Cómo ejecutar**: Revisa la sección "Comandos para Ejecutar"
- **Qué implementar**: Revisa la sección "Identificación de Datos"
- **Errores en tests**: Lee el mensaje del test, indica qué esperaba vs qué recibió

---

## 🎉 ¡Éxito en tu Implementación!

Este ejercicio te ayudará a dominar conceptos fundamentales de programación orientada a objetos y lógica de negocio. Toma tu tiempo, prueba frecuentemente y no dudes en experimentar.

**Recuerda:** El mejor código es el que funciona correctamente y cumple todas las reglas de negocio. ¡Adelante!
